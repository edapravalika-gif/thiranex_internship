# Customer Segmentation Project

## Objective
Segment customers based on purchasing behavior and demographic characteristics using Python and scikit-learn.

## Dataset
- 2,240 customer records
- 29 original columns
- Missing Income values were filled with the median.
- An extreme Income value was capped at the 99th percentile for clustering stability.

## Method
1. Created behavioral features:
   - Total Spend
   - Total Purchases
   - Total Children
2. Selected demographic and behavioral variables.
3. Standardized features with `StandardScaler`.
4. Applied K-Means clustering with 4 clusters.
5. Used PCA to visualize the clusters in two dimensions.

## Features Used
Income, Recency, Total_Spend, Total_Purchases, NumDealsPurchases, NumWebVisitsMonth, Total_Children

## Outputs
- `customer_segmentation.py` — reproducible Python implementation
- `customer_segments.csv` — customer records with assigned cluster
- `cluster_summary.csv` — average characteristics of each cluster
- `customer_count_by_segment.png`
- `customer_segments_pca.png`
- `average_spend_by_segment.png`

## Tools
Python, Pandas, NumPy, Matplotlib, scikit-learn

## Note
Cluster numbers are model-generated labels. They do not inherently mean that one cluster is "better" than another; interpretation should be based on the observed characteristics.

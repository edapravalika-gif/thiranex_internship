import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA

df = pd.read_csv("56c1d62f-543d-4f8a-8409-5284ce7be13f.csv")

df["Total_Spend"] = df[
    ["MntWines","MntFruits","MntMeatProducts",
     "MntFishProducts","MntSweetProducts","MntGoldProds"]
].sum(axis=1)

df["Total_Purchases"] = df[
    ["NumWebPurchases","NumCatalogPurchases","NumStorePurchases"]
].sum(axis=1)

df["Total_Children"] = df["Kidhome"] + df["Teenhome"]

df["Income"] = df["Income"].fillna(df["Income"].median())
df["Income"] = df["Income"].clip(upper=df["Income"].quantile(0.99))

features = [
    "Income","Recency","Total_Spend","Total_Purchases",
    "NumDealsPurchases","NumWebVisitsMonth","Total_Children"
]

X = df[features]
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

kmeans = KMeans(n_clusters=4, random_state=42, n_init=10)
df["Cluster"] = kmeans.fit_predict(X_scaled)

pca = PCA(n_components=2, random_state=42)
X_pca = pca.fit_transform(X_scaled)

# Segment visualization
for cluster in sorted(df["Cluster"].unique()):
    mask = df["Cluster"].values == cluster
    plt.scatter(X_pca[mask, 0], X_pca[mask, 1],
                s=12, alpha=0.55, label=f"Cluster {cluster}")

plt.title("Customer Segmentation using K-Means")
plt.xlabel("Principal Component 1")
plt.ylabel("Principal Component 2")
plt.legend()
plt.tight_layout()
plt.show()

summary = df.groupby("Cluster")[features].mean().round(2)
summary["Customers"] = df["Cluster"].value_counts().sort_index()
print(summary)

df.to_csv("customer_segments.csv", index=False)
